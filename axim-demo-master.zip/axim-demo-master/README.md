| Language | Framework | Platform | Author |
| -------- | -------- |--------|--------|
| Nodejs | Express | Aximsoft AWS cloud| |
